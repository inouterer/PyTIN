from triangulation import Triangulation
from geometryutils import ContourGraf
from point import Point



from visualisation import plot_triangulation

from sample_data import point_in, trn_in, real, real_levels #Main тут код запуска

# Добавим точки по исходному набору
def input_data (point_in):
    points = []
    for i in range(0,len(point_in)-1, 3):
        point = Point(point_in[i], point_in[i+1], point_in[i+2])
        points.append(point)
    return points

triangles = []

# import random
# num_points = 1000
# min_coord, max_coord = 0, 1000
# points = [Point(random.uniform(min_coord, max_coord), random.uniform(min_coord, max_coord),0) for _ in range(num_points)]

points = input_data(point_in) #Создали список объектов класса Points по рабочему набору
surface = Triangulation()
surface.triangulate(points)
surface.filter_triangles(1000, 10)
surface.get_bounds()

#surface.levels = real_levels
surface.define_contours_levels(0, 3)
surface.build_contour_lines()
#surface.contours_levels()
#surface.smooth_contour_lines(5,0.1)
#surface.build_isocontours()

#plot_triangulation(surface)

graf = ContourGraf()
graf.add_bounds(surface.bounds)
graf.add_isolines(surface.contour_lines)
graf.build_isocontours()
graf.visualize()
