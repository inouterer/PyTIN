class Point:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
        self.marked = False
    def __ne__(self, other):
        # Перегрузка оператора неравенства (!=)
        return (self.x != other.x) or (self.y != other.y)
    def __eq__(self, other):
        # Перегрузка оператора неравенства (!=)
        return (self.x == other.x) and (self.y == other.y)
    def __hash__(self):
        return hash((self.x, self.y))# Z???