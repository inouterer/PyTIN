from typing import List
from point import Point
from isocontour import Isocontour

class PolygonManager:
    def __init__(self):
        self.polygon = []

    # def remove_close_points(self, polyline, threshold = 1):
    #     new_polyline = [polyline[0]]  # Начнем с первой точки, так как ее мы не удаляем
    #     for i in range(1, len(polyline)-2):
    #         # Вычисляем расстояние между текущей точкой и предыдущей
    #         distance = ((polyline[i].x - new_polyline[-1].x) ** 2 + (polyline[i].y - new_polyline[-1].y) ** 2) ** 0.5
    #         # Если расстояние больше или равно пороговому значению, добавляем текущую точку в новую полилинию
    #         if distance == 0:
    #             continue
    #         if distance >= threshold:
    #             new_polyline.append(polyline[i])

    #     return new_polyline
    
    def remove_close_points(self, polyline, threshold=1):
        """Убирает очень короткие ребра полилинии, всегда осталяя первую и последнюю точки"""
        new_polyline = [polyline[0]]  # Начнем с первой точки, так как ее мы не удаляем
        for i in range(1, len(polyline) - 1):
            # Вычисляем расстояние между текущей точкой и предыдущей
            distance = ((polyline[i].x - new_polyline[-1].x) ** 2 + (polyline[i].y - new_polyline[-1].y) ** 2) ** 0.5
            # Если расстояние больше или равно пороговому значению, добавляем текущую точку в новую полилинию
            if distance == 0:
                continue
            if distance >= threshold:
                new_polyline.append(polyline[i])

        # Добавляем последнюю точку
        new_polyline.append(polyline[-1])
        # Проверяем предпоследнюю и удаляем, если она слишком близко
        if ((polyline[-1].x - new_polyline[-2].x) ** 2 + (polyline[-1].y - new_polyline[-2].y) ** 2) ** 0.5 <= threshold:
            del new_polyline[-2]
        return new_polyline
    
    # Порядок вершин всегда по часовой
    def ensure_clockwise (self):
        points = self.polygon
        area = 0
        n = len(points)
        for i in range(n):
            j = (i + 1) % n  # Следующая точка, циклически возвращаемся к первой
            x1, y1 = points[i].x, points[i].y
            x2, y2 = points[j].x, points[j].y
            area += x1 * y2 - x2 * y1
        if area < 0:
            # Ориентация уже по часовой стрелке
            self.polygon = points
        else:
            # Инвертируем порядок, чтобы сделать по часовой стрелке
            self.polygon = points[::-1]
    
    #Собираем линии из кусочков
    def assemble_polygon_from_noodles(self, noodles):#noodles это список списков точек
        """Собирает лапшу (список списка точек) в одну полилинию"""
        k = 0 
        polyline = []  # Создаем список с точками
        polyline = noodles[0] # Добавляем первую макаронину
        noodles.remove(noodles[0])  # Удаляем из списка
        while (len(noodles) > 0) and (k < len(noodles)):
            next_noodle = noodles[k]
            if next_noodle[-1] == polyline[0]:  # КОНЕЦ куска это НАЧАЛО полилинии
                polyline = next_noodle[:-1] + polyline  # Добавляем точки кроме последней в начало полилинии
                noodles.remove(noodles[k])
                k=0
                continue
            if next_noodle[0] == polyline[0]:  # НАЧАЛО куска это НАЧАЛО полилинии
                inverted_next_noodle = next_noodle[::-1] # Оборачиваем кусок
                polyline = inverted_next_noodle [:-1] + polyline  # Добавляем точки кроме последней в начало полилинии
                noodles.remove(noodles[k])
                k=0
                continue
            if next_noodle[0] == polyline[-1]:  # НАЧАЛО куска это КОНЕЦ полилинии 
                polyline = polyline + next_noodle[1:]# Добавляем точки кроме первой в конец полилинии
                noodles.remove(noodles[k])
                k=0
                continue
            if next_noodle[-1] == polyline[-1]:  # КОНЕЦ куска это КОНЕЦ полилинии
                inverted_next_noodle = next_noodle[::-1] # Оборачиваем кусок
                polyline = polyline + inverted_next_noodle[1:]# Добавляем точки кроме первой в конец полилинии
                noodles.remove(noodles[k])
                k=0
                continue
            if polyline[-1] == polyline[0]:
                k=0
                break
            k += 1

        self.polygon =  polyline
        return polyline

    

    def CatmullRomChain(self, P, nPoints, alpha):
        #Barry and Goldman's pyramidal formulation  Centripetal Catmull–Rom spline
        def pyramidalFormulation(P0, P1, P2, P3, nPoints, alpha):
            def knotParameters(ti, Pi, Pj):
                xi, yi, zi = Pi.x, Pi.y, Pi.z
                xj, yj, zj = Pj.x, Pj.y, Pj.z
                return ((xj - xi) ** 2 + (yj - yi) ** 2 + (zj - zi) ** 2) ** (alpha / 2) + ti

            t0 = 0
            t1 = knotParameters(t0, P0, P1)
            t2 = knotParameters(t1, P1, P2)
            t3 = knotParameters(t2, P2, P3)

            t = [t1 + (t2 - t1) * i / nPoints for i in range(nPoints)]

            A1_x = [(t1 - t_val) / (t1 - t0) * P0.x + (t_val - t0) / (t1 - t0) * P1.x for t_val in t]
            A1_y = [(t1 - t_val) / (t1 - t0) * P0.y + (t_val - t0) / (t1 - t0) * P1.y for t_val in t]

            A2_x = [(t2 - t_val) / (t2 - t1) * P1.x + (t_val - t1) / (t2 - t1) * P2.x for t_val in t]
            A2_y = [(t2 - t_val) / (t2 - t1) * P1.y + (t_val - t1) / (t2 - t1) * P2.y for t_val in t]

            A3_x = [(t3 - t_val) / (t3 - t2) * P2.x + (t_val - t2) / (t3 - t2) * P3.x for t_val in t]
            A3_y = [(t3 - t_val) / (t3 - t2) * P2.y + (t_val - t2) / (t3 - t2) * P3.y for t_val in t]

            B1_x = [(t2 - t_val) / (t2 - t0) * A1_x[i] + (t_val - t0) / (t2 - t0) * A2_x[i] for i, t_val in enumerate(t)]
            B1_y = [(t2 - t_val) / (t2 - t0) * A1_y[i] + (t_val - t0) / (t2 - t0) * A2_y[i] for i, t_val in enumerate(t)]

            B2_x = [(t3 - t_val) / (t3 - t1) * A2_x[i] + (t_val - t1) / (t3 - t1) * A3_x[i] for i, t_val in enumerate(t)]
            B2_y = [(t3 - t_val) / (t3 - t1) * A2_y[i] + (t_val - t1) / (t3 - t1) * A3_y[i] for i, t_val in enumerate(t)]

            C_x = [(t2 - t_val) / (t2 - t1) * B1_x[i] + (t_val - t1) / (t2 - t1) * B2_x[i] for i, t_val in enumerate(t)]
            C_y = [(t2 - t_val) / (t2 - t1) * B1_y[i] + (t_val - t1) / (t2 - t1) * B2_y[i] for i, t_val in enumerate(t)]

            return [Point(C_x[i], C_y[i], 0) for i in range(len(t))]

        length = len(P)
        Curve = []
        # if P[0] == P[-1]:
        #     P = P + [P[-1]]
        for i in range(length - 3):
            c = pyramidalFormulation(P[i], P[i + 1], P[i + 2], P[i + 3], nPoints, alpha)
            Curve.extend(c)
        if not P[0] == P[-1]:
            Curve = [P[0]] + Curve + [P[-1]]
        self.polygon =Curve


from isoline import IsoLine
import matplotlib.pyplot as plt

class ContourGraf:
    """
    Структура и методы для построения изоконтуров
    """
    def __init__(self) -> None:
        self.points = []
        self.isolines = []
        self.sections = []
        self.bounds = []
        self.isocotours = []

    def add_bounds (self, bounds: List[Point]):
        """Получит границы триангуляции"""
        self.bounds = bounds

    def add_isolines (self, isolines: List[IsoLine]):
        """Добавит изолинии из класса IsoLine как список списков точек"""
        lines = [line.points for line in isolines]
        self.isolines.extend(lines)

    def is_point_on_edge(self, point, a, b, epsilon=1e-3):
        """Расчет коллинеарности точки point с отрезком a-b"""
        if abs((point.y - a.y) * (b.x - a.x) - (b.y - a.y) * (point.x - a.x)) > epsilon:
            return False
        # Проверка, находится ли точка между вершинами a и b по обоим координатам с учетом допуска
        if min(a.x, b.x) - epsilon <= point.x <= max(a.x, b.x) + epsilon and min(a.y, b.y) - epsilon <= point.y <= max(a.y, b.y) + epsilon:
            return True
        return False

    def sort_points_on_edge(self, points, a, b):
        """Сортировка точек на ребре по их проекции на вектор ребра"""
        points.sort(key=lambda p: ((p.x - a.x) * (b.x - a.x) + (p.y - a.y) * (b.y - a.y)))
        for point in points:
            point.marked = True
        return points

    def find_and_sort_points_on_polygon(self, points):
        """
        Находим и сортируем точки на графе так,
        что бы включить в него все точки границы и входы и
        выходы полилиний по порядку по часовой стрелке
        """
        ordered_points = []
        n = len(self.bounds)
        for i in range(n):
            a = self.bounds[i]
            b = self.bounds[(i + 1) % n]
            points_on_edge = [p for p in points if self.is_point_on_edge(p, a, b)]
            if points_on_edge:
                sorted_points = self.sort_points_on_edge(points_on_edge, a, b)
                ordered_points.append(a)
                ordered_points.extend(sorted_points)
            else:
                ordered_points.append(a)
        return ordered_points[:-1] #Не добавляем последнюю точку, чтобы не задваивалась
    
    def find_isoline_for_point  (self, point):
        """Ищем изолинию, в которой точка"""
        for isoline in self.isolines:
            if (isoline[0] == point) or (isoline[-1] == point):
                return isoline

    
    def build_isocontours (self):
        """Непосредственно строим изоконтуры"""

        def find_point_index(point):
            """Поиск номера точки на контуре графа"""
            for i, p in enumerate(self.points):
                if point == p:
                    return i
            return -1
        
        #Здесь мы создаём точки графа, проходя по контуру объекта на его узлах и
        #на входах и выходах изолиний в порядке по часовой
        edge_points = []
        for isoline in self.isolines:
            for point in isoline:
                edge_points.append(point)
        self.points = self.find_and_sort_points_on_polygon(edge_points)
        

              
        #Добавляем замкнутые изолинии - они уже готовые изоконтуры
        for isoline in self.isolines:
            if isoline[0] == isoline[-1]:
                low_level = isoline[0].z #Нижнее значение изоконтура
                iso = Isocontour(low_level, 0)  # Создаем новый объект Isocontour
                iso.add_points(isoline)  # Добавляем точки в объект Isocontour
                self.isocotours.append(iso)

        #Сделаем ребра графа. 
        if len(self.points) < 2:
            return
                # Создание отрезков между последовательными точками
        self.sections = [[self.points[i], self.points[i + 1]] for i in range(len(self.points) - 1)]
        # Добавление отрезка между последней и первой точкой, чтобы закрыть контур
        self.sections.append([self.points[-1], self.points[0]])


        def find_section_index (point):
            """Поиск номера сегмента на контуре графа"""
            for i, section in enumerate(self.sections):
                if point == section[0]:
                    return i

   

        def trace_isocontour():
            visited_sections = []
            manager = PolygonManager()
            s = 0
            while len(visited_sections) < len(self.sections):
                #Проходим по рёбрам или секциям графа и строим выходящие контуры
                contour_noodle = []
                isocontour = []
                if s > len (self.sections)-1:
                        s = 0
                section = self.sections[s]
                if section in visited_sections:
                    s+=1
                    continue

                while len(visited_sections) < len(self.sections):
                    if section not in visited_sections:
                        visited_sections.append(section)
                        contour_noodle.append(section)
                        s+=1
                    
                    if section[-1].marked:
                        finded_isoline = self.find_isoline_for_point (section[-1])
                        contour_noodle.append(finded_isoline)
                        
                    
                    isocontour = manager.assemble_polygon_from_noodles(contour_noodle)

                    if section[-1].marked:
                        s = find_section_index (isocontour [-1])

                    contour_noodle= []
                    contour_noodle.append(isocontour)

                    if isocontour[0] == isocontour[-1]:
                        iso = Isocontour(0, 0)  # Создаем новый объект Isocontour
                        iso.add_points(isocontour)  # Добавляем точки в объект Isocontour
                        self.isocotours.append(iso)  # Добавляем объект Isocontour в список isocotours
                        break
                    section = self.sections[s]
                  
        #self.visualize()
        trace_isocontour()


        #Находим диапазоны изолиний
        for isocontour in self.isocotours:
            levels = []
            for point in isocontour.points:
                for graf_point in self.points:
                    if point == graf_point:
                        levels.append(graf_point.z)
                if levels:
                    min_height = min(levels)
                    max_height = max(levels)
                    isocontour.from_height = round(min_height,1)
                    isocontour.to_height = round(max_height,1)

        #Сортируем по возрастанию нижней высоты
        self.isocotours = sorted(self.isocotours, key=lambda x: x.from_height)



    
    def visualize(self):

        # Визуализация точек
        for i, point in enumerate(self.points):
            plt.plot(point.x, point.y, 'bo')  # Синие точки
            plt.text(point.x, point.y, f"{i}z{round(point.z, 2)}", fontsize=8, verticalalignment='bottom', horizontalalignment='right')

        # Визуализация изолиний и их точек
        for isoline in self.isolines:
            x = [point.x for point in isoline]
            y = [point.y for point in isoline]
            plt.plot(x, y, 'r-')  # Красные линии

            # for point in points_list:
            #     plt.plot(point.x, point.y, 'ro')  # Красные точки

        # Визуализация границ
        x = [point.x for point in self.bounds]
        y = [point.y for point in self.bounds]
        plt.plot(x, y, 'g-')  # Зеленая линия

        import random

        # Визуализация изоконтуров с заливкой
        for isocontour in self.isocotours:
            contour_points = isocontour.get_contour_points()
            # Разделяем координаты x и y
            x_values = [point.x for point in contour_points]
            y_values = [point.y for point in contour_points]
            # Добавляем первую точку в конец для замыкания линии
            x_values.append(contour_points[0].x)
            y_values.append(contour_points[0].y)
            # Случайный цвет в формате RGB
            color = (random.random(), random.random(), random.random())
            plt.fill(x_values, y_values, color=color)  # Заливка с случайным цветом

        plt.xlabel('X')
        plt.ylabel('Y')
        plt.title('Visualization')
        plt.grid(True)
        plt.show()
    