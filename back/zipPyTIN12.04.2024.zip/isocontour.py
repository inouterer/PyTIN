class Isocontour:
    """Изоконтуры"""
    def __init__(self, from_height, to_height):
        self.from_height = from_height
        self.to_height = to_height
        self.points = []
    def add_points(self, points):
        self.points.extend(points)

    def get_contour_points (self):
        return self.points

    def clear_contour_points(self):
        self.points = []