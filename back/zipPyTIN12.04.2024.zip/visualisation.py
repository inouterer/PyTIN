import numpy as np  # Импортируем numpy для генерации случайных цветов
import matplotlib.pyplot as plt

#Отобразим результат
def plot_triangulation(surface):
    plt.figure(figsize=(8, 6))

    # Визуализация ребер триангуляции
    for triangle in surface.triangles:
        for edge in triangle.edges:
            plt.plot([edge.start.x, edge.end.x], [edge.start.y, edge.end.y], color='gray')

    # Визуализация границ триангуляции
    for i in range(len(surface.bounds)):
        plt.plot([surface.bounds[i - 1].x, surface.bounds[i].x], [surface.bounds[i - 1].y, surface.bounds[i].y], color='blue')
    
    # Добавление точек на границе с отметками
    i=0
    for point in surface.bounds:
        plt.scatter(point.x, point.y, color='red')  # Рисуем точку
        plt.annotate(f'h{point.z}n{i}', (point.x, point.y), textcoords="offset points", xytext=(0,10), ha='center')
        i+=1

    # Визуализация изолиний
    for contour_line in surface.contour_lines:
        # Генерация случайного цвета
        color = np.random.rand(3,)
        x = [point.x for point in contour_line.points]
        y = [point.y for point in contour_line.points]
        plt.plot(x, y, color='pink')

    # Визуализация сглаженных изолиний
    for contour_line in surface.sm_contour_lines:
        # Генерация случайного цвета
        color = np.random.rand(3,)
        x = [point.x for point in contour_line.points]
        y = [point.y for point in contour_line.points]
        plt.plot(x, y, color=color)

    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Triangulation Plot')
    plt.grid(True)
    plt.show()
